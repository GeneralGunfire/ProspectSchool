import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { StatsBar } from './components/StatsBar';
import { AudienceSection } from './components/AudienceSection';
import { StudentDeepDive } from './components/StudentDeepDive';
import { StudyLibrary } from './components/StudyLibrary';
import { TeacherTools } from './components/TeacherTools';
import { QuoteSection } from './components/QuoteSection';
import { Pricing } from './components/Pricing';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';

/**
 * Prospect Landing Page
 * Full-screen landing page for a South African education platform.
 */
export default function App() {
  return (
    <main className="relative min-h-screen">
      <Navbar />
      <Hero />
      <StatsBar />
      <AudienceSection />
      <StudentDeepDive />
      <StudyLibrary />
      <TeacherTools />
      <QuoteSection />
      <Pricing />
      <FinalCTA />
      <Footer />
    </main>
  );
}

